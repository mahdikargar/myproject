﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
//using System.Runtime.InteropServices;

namespace shamsipoor
{
    public partial class Form_Reg : Form
    {
        public Form_Reg()
        {
            InitializeComponent();
        }
        //private const int SC_CLOSE = 0xF060;
        //private const int MF_GRAYED = 0x1;
        //[DllImport("user32.dll")]
        //private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);
        //[DllImport("user32.dll")]
        //private static extern int EnableMenuItem(IntPtr hMenu, int wIDEnableItem, int wEnable);
        private void Form_Reg_Load(object sender, EventArgs e)
        {
            //EnableMenuItem(GetSystemMenu(this.Handle, false), SC_CLOSE, MF_GRAYED);
        }
        string checkse = "", comtech = "", comstu = "";
        private void But_Reg_Click(object sender, EventArgs e)
        {

            if (radio_stu.Checked == true)
            {

                if (text_name_stu.Text == null && text_lname_stu.Text == null && text_nsh_stu.Text == null && radio_s_stu_man.Checked == false || radio_s_stu_wman.Checked == false && combo_stu.SelectedIndex == -1)
                {

                    MessageBox.Show("اطلاعات شما ثبت نشد");

                }
                else
                {

                    MessageBox.Show("اطلاعات شما ثبت شد برای ادامه ثبت نهایی کنید");
                    comstu = combo_stu.SelectedItem.ToString();
                    but_reg_end.Enabled = true;

                }

            }
            else if (radio_tech.Checked == true)
            {

                if (text_name_tech.Text == null && text_lname_tech.Text == null && text_nsh_tech.Text == null && combo_tech.SelectedIndex == -1)
                {

                    MessageBox.Show("اطلاعات شما ثبت نشد");

                }
                else
                {

                    MessageBox.Show("اطلاعات شما ثبت شد برای ادامه ثبت نهایی کنید");
                    comtech = combo_tech.SelectedItem.ToString();
                    but_reg_end.Enabled = true;

                }
                
            }

        }

        private void But_Back_Click(object sender, EventArgs e)
        {

            Form_Log frm = new Form_Log();
            frm.Visible = true;
            this.Close();


        }

        private void radio_stu_CheckedChanged(object sender, EventArgs e)
        {

            if (radio_stu.Checked == true)
            {

                group_stu.Enabled = true;
                group_tech.Enabled = false;

            }
            else if (radio_tech.Checked == true)
            {

                group_tech.Enabled = true;
                group_stu.Enabled = false;

            }

        }

        private void radio_tech_CheckedChanged(object sender, EventArgs e)
        {

            if (radio_tech.Checked == true)
            {

                group_stu.Enabled = false;
                group_tech.Enabled = true;

            }
            else if (radio_stu.Checked == true)
            {

                group_tech.Enabled = false;
                group_stu.Enabled = true;

            }

        }
        private void text_nsh_stu_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (char.IsLetter(e.KeyChar) == true)
            {
                e.Handled = true;
            }

        }

        private void text_nsh_tech_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (char.IsLetter(e.KeyChar) == true)
            {
                e.Handled = true;
            }

        }



        int stunum = 952112, technum = 111111, person = 0, major = 0;
        private void but_reg_end_Click(object sender, EventArgs e)
        {
            if (radio_s_stu_man.Checked == true || radio_s_tech_man.Checked == true) checkse = "MEN";
            else if (radio_s_stu_wman.Checked == true || radio_s_tech_wman.Checked == true) checkse = "WMEN";
            string constring = "data source = m_mahdikargar; initial catalog = shamsipoor1; integrated security = True; MultipleActiveResultSets = True; ";

            using (SqlConnection connect = new SqlConnection(constring))
            {

                connect.Open();
                    //stu
                    if (radio_stu.Checked == true)

                {
                    using (SqlCommand command0 = new SqlCommand("select count(*) from Tb_Person", connect))
                    {

                        person = (int)command0.ExecuteScalar()+1;
                        stunum += person;

                    }
                    using (SqlCommand command01 = new SqlCommand("select count(*) from Tb_Major", connect))
                    {

                        major = (int)command01.ExecuteScalar() + 1;

                    }

                    using (SqlCommand command = new SqlCommand("insert into Tb_Person(L_NAME,F_NAME,AGE,NATIONAL_ID,CITY,SEX)values('" + text_name_stu.Text + "' , '" + text_lname_stu.Text + "','" + numeric_stu.Value + "','" + text_nsh_stu.Text + "','" + text_city_stu.Text + "','" + checkse + "');", connect))
                    {

                        using (SqlDataReader rdrstu = command.ExecuteReader()) ;

                    }

                    using (SqlCommand command1 = new SqlCommand("insert into Tb_Major(MAJOR_NAME)values('" + comstu + "');", connect))

                    {

                        using (SqlDataReader rdrstu1 = command1.ExecuteReader()) ;

                    }
                    using (SqlCommand command2 = new SqlCommand("insert into Tb_Student(STUDENT_NUMBER,PERSON_ID,MAJOR_ID)values('" + stunum + "' , '" + person + "' , '"+ major + "');", connect))
                    {

                        using (SqlDataReader rdrstu2 = command2.ExecuteReader())
                        {
                            MessageBox.Show("اطلاعات شما وارد شدو در درایور شما سیو شد." + "\r\n" + "نام کاربری:" + "\r\n" + stunum + "\r\n" + "رمز ورود:" + "\r\n" + text_nsh_stu.Text);
                            
                        TextWriter tw = new StreamWriter("D:\\userpass.Txt");

                            tw.WriteLine("نام کاربری: " + "\r\n" + stunum + "\r\n" + "رمز ورود: " + "\r\n" + text_nsh_stu.Text);

                            tw.Close();
                        }

                    }
                    text_name_stu.Text = null; text_lname_stu.Text = null; text_nsh_stu.Text = null;
                    radio_s_stu_man.Checked = false; radio_s_stu_wman.Checked = false;
                    combo_stu.SelectedIndex = -1;
                }

                //tech
                else if (radio_tech.Checked == true)
                {
                    using (SqlCommand command00 = new SqlCommand("select count(*) from Tb_Person", connect))
                    {

                        person = (int)command00.ExecuteScalar() + 1;
                        technum += person;

                    }
                    using (SqlCommand command001 = new SqlCommand("select count(*) from Tb_Major", connect))
                    {

                        major = (int)command001.ExecuteScalar() + 1;

                    }

                    using (SqlCommand command3 = new SqlCommand("insert into Tb_Person(L_NAME,F_NAME,AGE,NATIONAL_ID,CITY,SEX)values('" + text_name_tech.Text + "' , '" + text_lname_tech.Text + "','" + numeric_tech.Value + "','" + text_nsh_tech.Text + "','" + text_city_tech.Text + "','" + checkse + "');", connect))
                    {

                        using (SqlDataReader rdrtech3 = command3.ExecuteReader()) ;

                    }

                    using (SqlCommand command4 = new SqlCommand("insert into Tb_Major(MAJOR_NAME)values('" + comtech + "');", connect))

                    {

                        using (SqlDataReader rdrtech4 = command4.ExecuteReader()) ;
                          
                    }

                    using (SqlCommand command5 = new SqlCommand("insert into Tb_Teacher(TEACHER_NUMBER,PERSON_ID,MAJOR_ID)values('" + technum +"','"+ person + "' , '" + major + "');", connect))
                    {

                        using (SqlDataReader rdrstu5 = command5.ExecuteReader()) MessageBox.Show("طلاعات شما وارد شدو در درایور شما سیو شد" + "\r\n" + "نام کاربری:" + "\r\n" +technum+ "\r\n" + "رمز ورود:" + "\r\n" + text_nsh_tech.Text);

                        TextWriter tw = new StreamWriter("D:\\userpass.Txt");

                        tw.WriteLine("نام کاربری: " + "\r\n" + technum + "\r\n" + "رمز ورود: " + "\r\n" + text_nsh_tech.Text);

                        tw.Close();
                    }
                    text_name_tech.Text = null; text_lname_tech.Text = null; text_nsh_tech.Text = null;
                    radio_s_tech_man.Checked = false; radio_s_tech_wman.Checked = false;
                    combo_tech.SelectedIndex = -1;
                }
                connect.Close();
                but_reg_end.Enabled = false;
            }
        }
    }
}
           

