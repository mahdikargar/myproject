﻿namespace shamsipoor
{
    partial class Form_Reg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Reg));
            this.But_Back = new System.Windows.Forms.Button();
            this.But_Reg = new System.Windows.Forms.Button();
            this.group_tech = new System.Windows.Forms.GroupBox();
            this.combo_tech = new System.Windows.Forms.ComboBox();
            this.radio_s_tech_man = new System.Windows.Forms.RadioButton();
            this.radio_s_tech_wman = new System.Windows.Forms.RadioButton();
            this.text_city_tech = new System.Windows.Forms.TextBox();
            this.text_nsh_tech = new System.Windows.Forms.TextBox();
            this.numeric_tech = new System.Windows.Forms.NumericUpDown();
            this.text_lname_tech = new System.Windows.Forms.TextBox();
            this.text_name_tech = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.group_stu = new System.Windows.Forms.GroupBox();
            this.combo_stu = new System.Windows.Forms.ComboBox();
            this.radio_s_stu_man = new System.Windows.Forms.RadioButton();
            this.radio_s_stu_wman = new System.Windows.Forms.RadioButton();
            this.text_city_stu = new System.Windows.Forms.TextBox();
            this.text_nsh_stu = new System.Windows.Forms.TextBox();
            this.numeric_stu = new System.Windows.Forms.NumericUpDown();
            this.text_lname_stu = new System.Windows.Forms.TextBox();
            this.text_name_stu = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.radio_stu = new System.Windows.Forms.RadioButton();
            this.radio_tech = new System.Windows.Forms.RadioButton();
            this.but_reg_end = new System.Windows.Forms.Button();
            this.group_tech.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeric_tech)).BeginInit();
            this.group_stu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeric_stu)).BeginInit();
            this.SuspendLayout();
            // 
            // But_Back
            // 
            this.But_Back.Font = new System.Drawing.Font("Khandevane", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.But_Back.Location = new System.Drawing.Point(12, 442);
            this.But_Back.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.But_Back.Name = "But_Back";
            this.But_Back.Size = new System.Drawing.Size(74, 54);
            this.But_Back.TabIndex = 0;
            this.But_Back.Text = "بازگشت";
            this.But_Back.UseVisualStyleBackColor = true;
            this.But_Back.Click += new System.EventHandler(this.But_Back_Click);
            // 
            // But_Reg
            // 
            this.But_Reg.Font = new System.Drawing.Font("Khandevane", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.But_Reg.Location = new System.Drawing.Point(481, 442);
            this.But_Reg.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.But_Reg.Name = "But_Reg";
            this.But_Reg.Size = new System.Drawing.Size(74, 54);
            this.But_Reg.TabIndex = 1;
            this.But_Reg.Text = "ثبت";
            this.But_Reg.UseVisualStyleBackColor = true;
            this.But_Reg.Click += new System.EventHandler(this.But_Reg_Click);
            // 
            // group_tech
            // 
            this.group_tech.Controls.Add(this.combo_tech);
            this.group_tech.Controls.Add(this.radio_s_tech_man);
            this.group_tech.Controls.Add(this.radio_s_tech_wman);
            this.group_tech.Controls.Add(this.text_city_tech);
            this.group_tech.Controls.Add(this.text_nsh_tech);
            this.group_tech.Controls.Add(this.numeric_tech);
            this.group_tech.Controls.Add(this.text_lname_tech);
            this.group_tech.Controls.Add(this.text_name_tech);
            this.group_tech.Controls.Add(this.label14);
            this.group_tech.Controls.Add(this.label6);
            this.group_tech.Controls.Add(this.label5);
            this.group_tech.Controls.Add(this.label4);
            this.group_tech.Controls.Add(this.label3);
            this.group_tech.Controls.Add(this.label2);
            this.group_tech.Controls.Add(this.label1);
            this.group_tech.Enabled = false;
            this.group_tech.Font = new System.Drawing.Font("Khandevane", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.group_tech.Location = new System.Drawing.Point(12, 42);
            this.group_tech.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.group_tech.Name = "group_tech";
            this.group_tech.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.group_tech.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.group_tech.Size = new System.Drawing.Size(235, 392);
            this.group_tech.TabIndex = 2;
            this.group_tech.TabStop = false;
            this.group_tech.Text = "استاد";
            // 
            // combo_tech
            // 
            this.combo_tech.FormattingEnabled = true;
            this.combo_tech.Items.AddRange(new object[] {
            "comp",
            "it",
            "ict"});
            this.combo_tech.Location = new System.Drawing.Point(6, 340);
            this.combo_tech.Name = "combo_tech";
            this.combo_tech.Size = new System.Drawing.Size(100, 30);
            this.combo_tech.TabIndex = 28;
            // 
            // radio_s_tech_man
            // 
            this.radio_s_tech_man.AutoSize = true;
            this.radio_s_tech_man.Checked = true;
            this.radio_s_tech_man.Location = new System.Drawing.Point(92, 288);
            this.radio_s_tech_man.Name = "radio_s_tech_man";
            this.radio_s_tech_man.Size = new System.Drawing.Size(48, 26);
            this.radio_s_tech_man.TabIndex = 27;
            this.radio_s_tech_man.TabStop = true;
            this.radio_s_tech_man.Text = "مرد";
            this.radio_s_tech_man.UseVisualStyleBackColor = true;
            // 
            // radio_s_tech_wman
            // 
            this.radio_s_tech_wman.AutoSize = true;
            this.radio_s_tech_wman.Location = new System.Drawing.Point(6, 288);
            this.radio_s_tech_wman.Name = "radio_s_tech_wman";
            this.radio_s_tech_wman.Size = new System.Drawing.Size(43, 26);
            this.radio_s_tech_wman.TabIndex = 26;
            this.radio_s_tech_wman.Text = "زن";
            this.radio_s_tech_wman.UseVisualStyleBackColor = true;
            // 
            // text_city_tech
            // 
            this.text_city_tech.Location = new System.Drawing.Point(6, 236);
            this.text_city_tech.Name = "text_city_tech";
            this.text_city_tech.Size = new System.Drawing.Size(100, 29);
            this.text_city_tech.TabIndex = 22;
            // 
            // text_nsh_tech
            // 
            this.text_nsh_tech.Location = new System.Drawing.Point(6, 181);
            this.text_nsh_tech.Name = "text_nsh_tech";
            this.text_nsh_tech.Size = new System.Drawing.Size(100, 29);
            this.text_nsh_tech.TabIndex = 21;
            this.text_nsh_tech.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_nsh_tech_KeyPress);
            // 
            // numeric_tech
            // 
            this.numeric_tech.Location = new System.Drawing.Point(6, 127);
            this.numeric_tech.Minimum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.numeric_tech.Name = "numeric_tech";
            this.numeric_tech.Size = new System.Drawing.Size(100, 29);
            this.numeric_tech.TabIndex = 20;
            this.numeric_tech.Value = new decimal(new int[] {
            24,
            0,
            0,
            0});
            // 
            // text_lname_tech
            // 
            this.text_lname_tech.Location = new System.Drawing.Point(6, 79);
            this.text_lname_tech.Name = "text_lname_tech";
            this.text_lname_tech.Size = new System.Drawing.Size(100, 29);
            this.text_lname_tech.TabIndex = 19;
            // 
            // text_name_tech
            // 
            this.text_name_tech.Location = new System.Drawing.Point(6, 34);
            this.text_name_tech.Name = "text_name_tech";
            this.text_name_tech.Size = new System.Drawing.Size(100, 29);
            this.text_name_tech.TabIndex = 18;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(182, 343);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 22);
            this.label14.TabIndex = 17;
            this.label14.Text = "رشته:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(171, 290);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 22);
            this.label6.TabIndex = 9;
            this.label6.Text = "جنسیت:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(186, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 22);
            this.label5.TabIndex = 8;
            this.label5.Text = "شهر:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(174, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 22);
            this.label4.TabIndex = 7;
            this.label4.Text = "کد ملی:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(191, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 22);
            this.label3.TabIndex = 6;
            this.label3.Text = "سن:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(147, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 22);
            this.label2.TabIndex = 5;
            this.label2.Text = "نام خانوادگی:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(194, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 22);
            this.label1.TabIndex = 4;
            this.label1.Text = "نام:";
            // 
            // group_stu
            // 
            this.group_stu.Controls.Add(this.combo_stu);
            this.group_stu.Controls.Add(this.radio_s_stu_man);
            this.group_stu.Controls.Add(this.radio_s_stu_wman);
            this.group_stu.Controls.Add(this.text_city_stu);
            this.group_stu.Controls.Add(this.text_nsh_stu);
            this.group_stu.Controls.Add(this.numeric_stu);
            this.group_stu.Controls.Add(this.text_lname_stu);
            this.group_stu.Controls.Add(this.text_name_stu);
            this.group_stu.Controls.Add(this.label13);
            this.group_stu.Controls.Add(this.label7);
            this.group_stu.Controls.Add(this.label8);
            this.group_stu.Controls.Add(this.label9);
            this.group_stu.Controls.Add(this.label10);
            this.group_stu.Controls.Add(this.label11);
            this.group_stu.Controls.Add(this.label12);
            this.group_stu.Enabled = false;
            this.group_stu.Font = new System.Drawing.Font("Khandevane", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.group_stu.Location = new System.Drawing.Point(324, 42);
            this.group_stu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.group_stu.Name = "group_stu";
            this.group_stu.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.group_stu.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.group_stu.Size = new System.Drawing.Size(231, 392);
            this.group_stu.TabIndex = 3;
            this.group_stu.TabStop = false;
            this.group_stu.Text = "دانشجو";
            // 
            // combo_stu
            // 
            this.combo_stu.FormattingEnabled = true;
            this.combo_stu.Items.AddRange(new object[] {
            "comp",
            "it",
            "ict"});
            this.combo_stu.Location = new System.Drawing.Point(6, 335);
            this.combo_stu.Name = "combo_stu";
            this.combo_stu.Size = new System.Drawing.Size(100, 30);
            this.combo_stu.TabIndex = 23;
            // 
            // radio_s_stu_man
            // 
            this.radio_s_stu_man.AutoSize = true;
            this.radio_s_stu_man.Checked = true;
            this.radio_s_stu_man.Location = new System.Drawing.Point(93, 292);
            this.radio_s_stu_man.Name = "radio_s_stu_man";
            this.radio_s_stu_man.Size = new System.Drawing.Size(48, 26);
            this.radio_s_stu_man.TabIndex = 22;
            this.radio_s_stu_man.TabStop = true;
            this.radio_s_stu_man.Text = "مرد";
            this.radio_s_stu_man.UseVisualStyleBackColor = true;
            // 
            // radio_s_stu_wman
            // 
            this.radio_s_stu_wman.AutoSize = true;
            this.radio_s_stu_wman.Location = new System.Drawing.Point(7, 292);
            this.radio_s_stu_wman.Name = "radio_s_stu_wman";
            this.radio_s_stu_wman.Size = new System.Drawing.Size(43, 26);
            this.radio_s_stu_wman.TabIndex = 21;
            this.radio_s_stu_wman.Text = "زن";
            this.radio_s_stu_wman.UseVisualStyleBackColor = true;
            // 
            // text_city_stu
            // 
            this.text_city_stu.Location = new System.Drawing.Point(6, 239);
            this.text_city_stu.Name = "text_city_stu";
            this.text_city_stu.Size = new System.Drawing.Size(100, 29);
            this.text_city_stu.TabIndex = 20;
            // 
            // text_nsh_stu
            // 
            this.text_nsh_stu.Location = new System.Drawing.Point(6, 181);
            this.text_nsh_stu.Name = "text_nsh_stu";
            this.text_nsh_stu.Size = new System.Drawing.Size(100, 29);
            this.text_nsh_stu.TabIndex = 19;
            this.text_nsh_stu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_nsh_stu_KeyPress);
            // 
            // numeric_stu
            // 
            this.numeric_stu.Location = new System.Drawing.Point(6, 127);
            this.numeric_stu.Minimum = new decimal(new int[] {
            17,
            0,
            0,
            0});
            this.numeric_stu.Name = "numeric_stu";
            this.numeric_stu.Size = new System.Drawing.Size(100, 29);
            this.numeric_stu.TabIndex = 18;
            this.numeric_stu.Value = new decimal(new int[] {
            17,
            0,
            0,
            0});
            // 
            // text_lname_stu
            // 
            this.text_lname_stu.Location = new System.Drawing.Point(6, 81);
            this.text_lname_stu.Name = "text_lname_stu";
            this.text_lname_stu.Size = new System.Drawing.Size(100, 29);
            this.text_lname_stu.TabIndex = 17;
            // 
            // text_name_stu
            // 
            this.text_name_stu.Location = new System.Drawing.Point(6, 35);
            this.text_name_stu.Name = "text_name_stu";
            this.text_name_stu.Size = new System.Drawing.Size(100, 29);
            this.text_name_stu.TabIndex = 6;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(178, 343);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 22);
            this.label13.TabIndex = 16;
            this.label13.Text = "رشته:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(167, 292);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 22);
            this.label7.TabIndex = 15;
            this.label7.Text = "جنسیت:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(182, 239);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 22);
            this.label8.TabIndex = 14;
            this.label8.Text = "شهر:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(170, 188);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 22);
            this.label9.TabIndex = 13;
            this.label9.Text = "کد ملی:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(187, 134);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 22);
            this.label10.TabIndex = 12;
            this.label10.Text = "سن:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(143, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 22);
            this.label11.TabIndex = 11;
            this.label11.Text = "نام خانوادگی:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(190, 41);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 22);
            this.label12.TabIndex = 10;
            this.label12.Text = "نام:";
            // 
            // radio_stu
            // 
            this.radio_stu.AutoSize = true;
            this.radio_stu.Font = new System.Drawing.Font("Khandevane", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio_stu.Location = new System.Drawing.Point(398, 17);
            this.radio_stu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_stu.Name = "radio_stu";
            this.radio_stu.Size = new System.Drawing.Size(67, 26);
            this.radio_stu.TabIndex = 4;
            this.radio_stu.Text = "دانشجو";
            this.radio_stu.UseVisualStyleBackColor = true;
            this.radio_stu.CheckedChanged += new System.EventHandler(this.radio_stu_CheckedChanged);
            // 
            // radio_tech
            // 
            this.radio_tech.AutoSize = true;
            this.radio_tech.Font = new System.Drawing.Font("Khandevane", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio_tech.Location = new System.Drawing.Point(103, 17);
            this.radio_tech.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_tech.Name = "radio_tech";
            this.radio_tech.Size = new System.Drawing.Size(57, 26);
            this.radio_tech.TabIndex = 5;
            this.radio_tech.Text = "استاد";
            this.radio_tech.UseVisualStyleBackColor = true;
            this.radio_tech.CheckedChanged += new System.EventHandler(this.radio_tech_CheckedChanged);
            // 
            // but_reg_end
            // 
            this.but_reg_end.Enabled = false;
            this.but_reg_end.Font = new System.Drawing.Font("Khandevane", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_reg_end.Location = new System.Drawing.Point(215, 456);
            this.but_reg_end.Name = "but_reg_end";
            this.but_reg_end.Size = new System.Drawing.Size(133, 36);
            this.but_reg_end.TabIndex = 6;
            this.but_reg_end.Text = "ثبت نهایی";
            this.but_reg_end.UseVisualStyleBackColor = true;
            this.but_reg_end.Click += new System.EventHandler(this.but_reg_end_Click);
            // 
            // Form_Reg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(567, 504);
            this.ControlBox = false;
            this.Controls.Add(this.but_reg_end);
            this.Controls.Add(this.radio_tech);
            this.Controls.Add(this.radio_stu);
            this.Controls.Add(this.group_stu);
            this.Controls.Add(this.group_tech);
            this.Controls.Add(this.But_Reg);
            this.Controls.Add(this.But_Back);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Khandevane", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form_Reg";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ثبت نام ";
            this.Load += new System.EventHandler(this.Form_Reg_Load);
            this.group_tech.ResumeLayout(false);
            this.group_tech.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeric_tech)).EndInit();
            this.group_stu.ResumeLayout(false);
            this.group_stu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeric_stu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button But_Back;
        private System.Windows.Forms.Button But_Reg;
        private System.Windows.Forms.GroupBox group_tech;
        private System.Windows.Forms.GroupBox group_stu;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton radio_stu;
        private System.Windows.Forms.RadioButton radio_tech;
        private System.Windows.Forms.TextBox text_city_tech;
        private System.Windows.Forms.TextBox text_nsh_tech;
        private System.Windows.Forms.NumericUpDown numeric_tech;
        private System.Windows.Forms.TextBox text_lname_tech;
        private System.Windows.Forms.TextBox text_name_tech;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox text_city_stu;
        private System.Windows.Forms.TextBox text_nsh_stu;
        private System.Windows.Forms.NumericUpDown numeric_stu;
        private System.Windows.Forms.TextBox text_lname_stu;
        private System.Windows.Forms.TextBox text_name_stu;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RadioButton radio_s_stu_man;
        private System.Windows.Forms.RadioButton radio_s_stu_wman;
        private System.Windows.Forms.RadioButton radio_s_tech_man;
        private System.Windows.Forms.RadioButton radio_s_tech_wman;
        private System.Windows.Forms.ComboBox combo_stu;
        private System.Windows.Forms.ComboBox combo_tech;
        private System.Windows.Forms.Button but_reg_end;
    }
}