﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;


namespace shamsipoor
{
    public partial class Form_Select_unit : Form
    {
        public Form_Select_unit()
        {
            InitializeComponent();
        }

        private void But_Back_Click(object sender, EventArgs e)
        {

            Form_Log frm = new Form_Log();
            frm.Visible = true;
            this.Close();

        }

        private void text_us_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == true)
            {
                e.Handled = true;
            }
        }

        private void text_pass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == true)
            {
                e.Handled = true;
            }
        }
        private SqlConnection objconnection = new SqlConnection(@"data source = m_mahdikargar; initial catalog = shamsipoor1; integrated security = True; MultipleActiveResultSets = True; ");
        private SqlCommand objcommand;
        private SqlCommand objcommand1;

        public static string name = "";
        public static string Lname = "";
        private void but_enter_Click(object sender, EventArgs e)
        {


            if (radio_stu.Checked == true)
            {

                int i = 0, j = 0;
                try
                {

                    if (text_pass.Text == string.Empty)
                    {
                        MessageBox.Show("Enter Data !");
                        return;
                    }

                    objcommand = new SqlCommand(" select count(*) from Tb_Person " +
                        "WHERE  NATIONAL_ID=@Password", objconnection);
                    objcommand.Parameters.AddWithValue("@Password", text_pass.Text.ToString());

                    objcommand1 = new SqlCommand(" select count(*) from Tb_Student " +
                       "WHERE  STUDENT_NUMBER=@UserName", objconnection);
                    objcommand1.Parameters.AddWithValue("@UserName", text_us.Text.ToString());

                    if (objconnection.State == ConnectionState.Closed)
                    {
                        objconnection.Open();
                        i = (int)objcommand.ExecuteScalar();
                        j = (int)objcommand1.ExecuteScalar();
                    }//end if

                    objconnection.Close();

                    if (i >= 1 && j >= 1)
                    {
                        using (SqlCommand command2 = new SqlCommand("select * from Tb_Person,Tb_Student where (Tb_Person.ID=PERSON_ID and '" + text_us.Text + "'= STUDENT_NUMBER); ", objconnection))
                        {

                            SqlDataAdapter da = new SqlDataAdapter(command2);
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            for(int b=0;b< dt.Columns.Count;b++)
                            {

                                if (dt.Columns[b].ColumnName.Contains("L_NAME")) 
                                {

                                    label_name.Text = dt.Rows[0][b].ToString();

                                }

                                if (dt.Columns[b].ColumnName.Contains("F_NAME"))
                                {

                                    label_lname.Text = dt.Rows[0][b].ToString();

                                }

                            }

                        }
                        
                        groupBox2.Enabled = true;
                        label_nun.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("No Authentication !");
                        label_nun.Visible = true;
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
                finally
                {
                    i = 0;
                    j = 0;
                    objconnection.Close();
                }

                textBox1.Enabled  = true;
            }

            else if (radio_tech.Checked == true)
            {

                int i = 0, j = 0;
                try
                {

                    if (text_pass.Text == string.Empty)
                    {
                        MessageBox.Show("Enter Data !");
                        return;
                    }

                    objcommand = new SqlCommand(" select count(*) from Tb_Person " +
                        "WHERE  NATIONAL_ID=@Password", objconnection);
                    objcommand.Parameters.AddWithValue("@Password", text_pass.Text.ToString());

                    objcommand1 = new SqlCommand(" select count(*) from Tb_Teacher " +
                       "WHERE  TEACHER_NUMBER=@UserName", objconnection);
                    objcommand1.Parameters.AddWithValue("@UserName", text_us.Text.ToString());

                    if (objconnection.State == ConnectionState.Closed)
                    {
                        objconnection.Open();
                        i = (int)objcommand.ExecuteScalar();
                        j = (int)objcommand1.ExecuteScalar();
                    }//end if

                    objconnection.Close();

                    if (i > 0 && j >= 1)
                    {
                        using (SqlCommand command3 = new SqlCommand("select * from Tb_Person,Tb_Teacher where (Tb_Person.ID=PERSON_ID and '" + text_us.Text + "'= TEACHER_NUMBER); ", objconnection))
                        {

                            SqlDataAdapter da = new SqlDataAdapter(command3);
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            for (int C = 0; C < dt.Columns.Count; C++)
                            {

                                if (dt.Columns[C].ColumnName.Contains("L_NAME"))
                                {

                                    label_name.Text = dt.Rows[0][C].ToString();

                                }

                                if (dt.Columns[C].ColumnName.Contains("F_NAME"))
                                {

                                    label_lname.Text = dt.Rows[0][C].ToString();

                                }

                            }

                        }
                        groupBox2.Enabled = true;
                        label_nun.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("No Authentication !");
                        label_nun.Visible = true;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
                finally
                {
                   
                    i = 0; j = 0;
                    objconnection.Close();
                }
                textBox1.Enabled = true;
            }

        }
      
        private void but_end_Click(object sender, EventArgs e)
        {
            text_us.Text=text_pass.Text= string.Empty;
            radio_stu.Checked = radio_tech.Checked = false;
            textBox1.Text  = string.Empty;
            textBox1.Enabled  = false;
            groupBox2.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
        }

        private void radio_stu_CheckedChanged(object sender, EventArgs e)
        {
            if ((radio_stu.Checked == true) || (radio_tech.Checked == true))
            {

                groupBox1.Enabled = true;

            }
            else MessageBox.Show("select your postion");
        }

        private void radio_tech_CheckedChanged(object sender, EventArgs e)
        {
            if ((radio_stu.Checked == true) || (radio_tech.Checked == true))
            {

                groupBox1.Enabled = true;

            }
            else
            {

                MessageBox.Show("select your postion");
                groupBox1.Enabled = false;

            }
                
        }
        int maj_stu = 0,maj_tech=0;
        private void but_ok_Click(object sender, EventArgs e)
        {

            objconnection.Open();
            using (SqlCommand command = new SqlCommand("insert into Tb_Course(NAME_COU)values('" + textBox1.Text + "');", objconnection))

            {

                using (SqlDataReader rdrstu = command.ExecuteReader()) ;
                MessageBox.Show("درس ثبت شد");

            }
            if(radio_stu.Checked==true)
            {


                    using (SqlCommand command01 = new SqlCommand("select count(*) from Tb_Course", objconnection))
                    {

                        maj_stu = (int)command01.ExecuteScalar() + 1;

                    }

                using (SqlCommand command7 = new SqlCommand("insert into  Tb_Teacher(COURSE_ID)values('" + maj_stu + "');", objconnection))
                {

                    using (SqlDataReader rdrstu7 = command7.ExecuteReader())
                    {
                        MessageBox.Show("درس انتخابی شما ثبت شد!!!");
                    }

                }

            }

          
            else if (radio_tech.Checked == true)
            {
              

                    using (SqlCommand command01 = new SqlCommand("select count(*) from Tb_Course", objconnection))
                    {

                        maj_tech = (int)command01.ExecuteScalar() + 1;

                    }


                using (SqlCommand command6 = new SqlCommand("insert into  Tb_Teacher(COURSE_ID)values('" + maj_tech + "');", objconnection))
                {

                    using (SqlDataReader rdrstu6 = command6.ExecuteReader())
                    {
                        MessageBox.Show("درس انتخابی شما ثبت شد!!!");
                    }

                }

            }
            objconnection.Close();

        }
    }
}