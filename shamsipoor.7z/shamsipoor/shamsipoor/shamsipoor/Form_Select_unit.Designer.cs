﻿namespace shamsipoor
{
    partial class Form_Select_unit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.But_Back = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label_nun = new System.Windows.Forms.Label();
			this.but_enter = new System.Windows.Forms.Button();
			this.text_pass = new System.Windows.Forms.TextBox();
			this.text_us = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label_lname = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label_name = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.but_ok = new System.Windows.Forms.Button();
			this.but_end = new System.Windows.Forms.Button();
			this.radio_stu = new System.Windows.Forms.RadioButton();
			this.radio_tech = new System.Windows.Forms.RadioButton();
			this.button1 = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// But_Back
			// 
			this.But_Back.Font = new System.Drawing.Font("Khandevane", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.But_Back.Location = new System.Drawing.Point(7, 376);
			this.But_Back.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
			this.But_Back.Name = "But_Back";
			this.But_Back.Size = new System.Drawing.Size(149, 34);
			this.But_Back.TabIndex = 1;
			this.But_Back.Text = "بازگشت به صفحه اصلی";
			this.But_Back.UseVisualStyleBackColor = true;
			this.But_Back.Click += new System.EventHandler(this.But_Back_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label_nun);
			this.groupBox1.Controls.Add(this.but_enter);
			this.groupBox1.Controls.Add(this.text_pass);
			this.groupBox1.Controls.Add(this.text_us);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Enabled = false;
			this.groupBox1.Location = new System.Drawing.Point(7, 37);
			this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 5, 3, 5);
			this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.groupBox1.Size = new System.Drawing.Size(649, 102);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "ورود";
			// 
			// label_nun
			// 
			this.label_nun.AutoSize = true;
			this.label_nun.ForeColor = System.Drawing.Color.Red;
			this.label_nun.Location = new System.Drawing.Point(453, 67);
			this.label_nun.Name = "label_nun";
			this.label_nun.Size = new System.Drawing.Size(190, 21);
			this.label_nun.TabIndex = 3;
			this.label_nun.Text = "نام کاربری یا رمز ورود اشتبا است!!!";
			this.label_nun.Visible = false;
			// 
			// but_enter
			// 
			this.but_enter.Location = new System.Drawing.Point(7, 61);
			this.but_enter.Name = "but_enter";
			this.but_enter.Size = new System.Drawing.Size(88, 33);
			this.but_enter.TabIndex = 4;
			this.but_enter.Text = "ورود";
			this.but_enter.UseVisualStyleBackColor = true;
			this.but_enter.Click += new System.EventHandler(this.but_enter_Click);
			// 
			// text_pass
			// 
			this.text_pass.Location = new System.Drawing.Point(6, 27);
			this.text_pass.Name = "text_pass";
			this.text_pass.Size = new System.Drawing.Size(244, 28);
			this.text_pass.TabIndex = 3;
			this.text_pass.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_pass_KeyPress);
			// 
			// text_us
			// 
			this.text_us.Location = new System.Drawing.Point(324, 30);
			this.text_us.Name = "text_us";
			this.text_us.Size = new System.Drawing.Size(244, 28);
			this.text_us.TabIndex = 2;
			this.text_us.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_us_KeyPress);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(256, 30);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(61, 21);
			this.label2.TabIndex = 1;
			this.label2.Text = "رمز ورود:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(574, 30);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(69, 21);
			this.label1.TabIndex = 0;
			this.label1.Text = "نام کاربری:";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.textBox1);
			this.groupBox2.Controls.Add(this.label5);
			this.groupBox2.Controls.Add(this.label_lname);
			this.groupBox2.Controls.Add(this.label4);
			this.groupBox2.Controls.Add(this.label_name);
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Enabled = false;
			this.groupBox2.Location = new System.Drawing.Point(7, 138);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.groupBox2.Size = new System.Drawing.Size(649, 168);
			this.groupBox2.TabIndex = 3;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "انتخاب درس";
			// 
			// textBox1
			// 
			this.textBox1.Enabled = false;
			this.textBox1.Location = new System.Drawing.Point(5, 92);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(553, 28);
			this.textBox1.TabIndex = 9;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(571, 99);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(72, 21);
			this.label5.TabIndex = 4;
			this.label5.Text = "نام درس 1:";
			// 
			// label_lname
			// 
			this.label_lname.AutoSize = true;
			this.label_lname.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label_lname.Location = new System.Drawing.Point(75, 33);
			this.label_lname.Name = "label_lname";
			this.label_lname.Size = new System.Drawing.Size(2, 23);
			this.label_lname.TabIndex = 3;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(152, 35);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(77, 21);
			this.label4.TabIndex = 2;
			this.label4.Text = "نام خانوادگی:";
			// 
			// label_name
			// 
			this.label_name.AutoSize = true;
			this.label_name.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label_name.Location = new System.Drawing.Point(556, 35);
			this.label_name.Name = "label_name";
			this.label_name.Size = new System.Drawing.Size(2, 23);
			this.label_name.TabIndex = 1;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(610, 35);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(33, 21);
			this.label3.TabIndex = 0;
			this.label3.Text = "نام:";
			// 
			// but_ok
			// 
			this.but_ok.Font = new System.Drawing.Font("Khandevane", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.but_ok.Location = new System.Drawing.Point(552, 336);
			this.but_ok.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
			this.but_ok.Name = "but_ok";
			this.but_ok.Size = new System.Drawing.Size(94, 65);
			this.but_ok.TabIndex = 4;
			this.but_ok.Text = "ثبت درس";
			this.but_ok.UseVisualStyleBackColor = true;
			this.but_ok.Click += new System.EventHandler(this.but_ok_Click);
			// 
			// but_end
			// 
			this.but_end.Font = new System.Drawing.Font("Khandevane", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.but_end.Location = new System.Drawing.Point(7, 336);
			this.but_end.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
			this.but_end.Name = "but_end";
			this.but_end.Size = new System.Drawing.Size(149, 34);
			this.but_end.TabIndex = 5;
			this.but_end.Text = "خروج";
			this.but_end.UseVisualStyleBackColor = true;
			this.but_end.Click += new System.EventHandler(this.but_end_Click);
			// 
			// radio_stu
			// 
			this.radio_stu.AutoSize = true;
			this.radio_stu.Location = new System.Drawing.Point(460, 13);
			this.radio_stu.Name = "radio_stu";
			this.radio_stu.Size = new System.Drawing.Size(65, 25);
			this.radio_stu.TabIndex = 6;
			this.radio_stu.TabStop = true;
			this.radio_stu.Text = "دانشجو";
			this.radio_stu.UseVisualStyleBackColor = true;
			this.radio_stu.CheckedChanged += new System.EventHandler(this.radio_stu_CheckedChanged);
			// 
			// radio_tech
			// 
			this.radio_tech.AutoSize = true;
			this.radio_tech.Location = new System.Drawing.Point(159, 13);
			this.radio_tech.Name = "radio_tech";
			this.radio_tech.Size = new System.Drawing.Size(56, 25);
			this.radio_tech.TabIndex = 7;
			this.radio_tech.TabStop = true;
			this.radio_tech.Text = "استاد";
			this.radio_tech.UseVisualStyleBackColor = true;
			this.radio_tech.CheckedChanged += new System.EventHandler(this.radio_tech_CheckedChanged);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(182, 336);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 74);
			this.button1.TabIndex = 8;
			this.button1.Text = "پاک کردن همه";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// Form_Select_unit
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 21F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.ClientSize = new System.Drawing.Size(665, 590);
			this.ControlBox = false;
			this.Controls.Add(this.button1);
			this.Controls.Add(this.radio_tech);
			this.Controls.Add(this.radio_stu);
			this.Controls.Add(this.but_end);
			this.Controls.Add(this.but_ok);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.But_Back);
			this.Font = new System.Drawing.Font("Khandevane", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
			this.Name = "Form_Select_unit";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "انتخاب واحد";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button But_Back;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox text_pass;
        private System.Windows.Forms.TextBox text_us;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_nun;
        private System.Windows.Forms.Button but_enter;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label_lname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button but_ok;
        private System.Windows.Forms.Button but_end;
        private System.Windows.Forms.RadioButton radio_stu;
        private System.Windows.Forms.RadioButton radio_tech;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
    }
}